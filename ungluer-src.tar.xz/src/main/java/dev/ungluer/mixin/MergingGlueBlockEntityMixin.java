package dev.ungluer.mixin;

import dev.ungluer.StoredMergeGroups;
import dev.simulated_team.simulated.content.blocks.merging_glue.MergingGlueBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Rotation;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Runs just before the original component is transferred into the surviving Sable sub-level. */
@Mixin(value = MergingGlueBlockEntity.class, remap = false)
public abstract class MergingGlueBlockEntityMixin {
    @Shadow @Nullable private BlockPos partnerPosition;

    @Inject(method = "disassembleToPartner", at = @At("HEAD"), remap = false)
    private void create_ungluer$rememberComponents(Rotation rotation, CallbackInfo ci) {
        MergingGlueBlockEntity glue = (MergingGlueBlockEntity) (Object) this;
        if (glue.getLevel() == null || glue.getLevel().isClientSide || partnerPosition == null) return;
        StoredMergeGroups.recordBeforeMerge(glue, partnerPosition, rotation);
    }
}
