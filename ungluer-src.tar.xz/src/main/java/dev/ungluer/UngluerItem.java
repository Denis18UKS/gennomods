package dev.ungluer;

import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.SubLevelAssemblyHelper;
import dev.ryanhcode.sable.companion.math.BoundingBox3i;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

import java.util.ArrayList;
import java.util.List;

/** Splits the remembered source part of a previous slime-ball merge back into its own rigid body. */
public final class UngluerItem extends Item {
    public UngluerItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getLevel().isClientSide) return InteractionResult.SUCCESS;
        if (!(ctx.getLevel() instanceof ServerLevel level)) return InteractionResult.FAIL;

        BlockPos hit = ctx.getClickedPos();
        SubLevel containing = Sable.HELPER.getContaining(level, hit);
        if (!(containing instanceof ServerSubLevel parent)) {
            msg(ctx, "message.create_ungluer.not_physics");
            return InteractionResult.FAIL;
        }

        StoredMergeGroups.Group chosen = StoredMergeGroups.select(parent, hit);
        if (chosen == null) {
            msg(ctx, "message.create_ungluer.no_history");
            return InteractionResult.FAIL;
        }

        List<BlockPos> members = new ArrayList<>();
        for (long packed : chosen.blocks()) {
            BlockPos p = BlockPos.of(packed);
            if (!level.getBlockState(p).isAir()) members.add(p);
        }
        if (members.isEmpty() || members.size() > StoredMergeGroups.MAX_BLOCKS) {
            msg(ctx, "message.create_ungluer.invalid_group");
            return InteractionResult.FAIL;
        }
        // Refuse if some original positions were deleted or replaced; no risky partial undo.
        if (members.size() != chosen.blocks().length) {
            msg(ctx, "message.create_ungluer.modified");
            return InteractionResult.FAIL;
        }
        try {
            BoundingBox3i bounds = BoundingBox3i.from(members).expand(1, 1, 1);
            BlockPos anchor = members.getFirst();
            ServerSubLevel separated = SubLevelAssemblyHelper.assembleBlocks(level, anchor, members, bounds);
            if (separated == null || separated.isRemoved()) {
                msg(ctx, "message.create_ungluer.failed");
                return InteractionResult.FAIL;
            }
            StoredMergeGroups.afterSplit(parent, separated, chosen, anchor);
            msg(ctx, "message.create_ungluer.success");
            return InteractionResult.SUCCESS;
        } catch (RuntimeException ex) {
            // The helper is not transactional. Always make a world backup before testing.
            msg(ctx, "message.create_ungluer.failed");
            return InteractionResult.FAIL;
        }
    }

    private static void msg(UseOnContext ctx, String key) {
        if (ctx.getPlayer() != null) ctx.getPlayer().displayClientMessage(Component.translatable(key), true);
    }
}
