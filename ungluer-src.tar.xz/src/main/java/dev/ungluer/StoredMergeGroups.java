package dev.ungluer;

import dev.ryanhcode.sable.Sable;
import dev.ryanhcode.sable.api.SubLevelAssemblyHelper;
import dev.ryanhcode.sable.companion.math.BoundingBox3ic;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.ryanhcode.sable.sublevel.plot.LevelPlot;
import dev.ryanhcode.sable.sublevel.plot.PlotChunkHolder;
import dev.simulated_team.simulated.content.blocks.merging_glue.MergingGlueBlock;
import dev.simulated_team.simulated.content.blocks.merging_glue.MergingGlueBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Rotation;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Persists the groups created by joining physics objects. Never stores original block contents:
 * only membership of the blocks in the surviving sub-level. The real blocks/BlockEntities remain
 * managed by Sable; no duplicated inventories or block entities are serialized here.
 */
public final class StoredMergeGroups {
    public static final int MAX_BLOCKS = 128_000;
    public static final int MAX_GROUPS = 128;
    private static final String ROOT = "create_ungluer";
    private static final String GROUPS = "groups";

    private StoredMergeGroups() { }

    public record Group(UUID id, long[] blocks) {
        boolean contains(long location) {
            for (long b : blocks) if (b == location) return true;
            return false;
        }
    }

    /** On entry to Simulated's disassembleToPartner(), before it moves the blocks. */
    public static void recordBeforeMerge(MergingGlueBlockEntity glue, BlockPos partnerPosition, Rotation rotation) {
        if (!(glue.getLevel() instanceof ServerLevel level)) return;
        BlockPos sourceAnchor = glue.getBlockPos().relative(glue.getBlockState().getValue(MergingGlueBlock.FACING).getOpposite());
        SubLevel s = Sable.HELPER.getContaining(level, sourceAnchor);
        SubLevel d = Sable.HELPER.getContaining(level, partnerPosition);
        if (!(s instanceof ServerSubLevel source) || !(d instanceof ServerSubLevel destination) || s == d) return;

        int angle = rotation == Rotation.NONE ? 0 : 4 - rotation.ordinal();
        SubLevelAssemblyHelper.AssemblyTransform transformation = new SubLevelAssemblyHelper.AssemblyTransform(
                sourceAnchor, partnerPosition, angle, rotation, level);

        List<Long> mapped = new ArrayList<>();
        LevelPlot plot = source.getPlot();
        for (PlotChunkHolder chunk : plot.getLoadedChunks()) {
            BoundingBox3ic bounds = chunk.getBoundingBox();
            if (bounds == null) continue;
            for (int x = bounds.minX(); x <= bounds.maxX(); x++)
                for (int y = bounds.minY(); y <= bounds.maxY(); y++)
                    for (int z = bounds.minZ(); z <= bounds.maxZ(); z++) {
                        BlockPos p = new BlockPos(x + chunk.getPos().getMinBlockX(), y, z + chunk.getPos().getMinBlockZ());
                        if (level.getBlockState(p).isAir()) continue;
                        mapped.add(transformation.apply(p).asLong());
                        if (mapped.size() > MAX_BLOCKS) return;
                    }
        }
        if (mapped.isEmpty()) return;

        List<Group> groups = read(destination);
        if (groups.size() >= MAX_GROUPS) return;
        // Remap child-history too: a third structure can later be split off independently.
        for (Group child : read(source)) {
            long[] remapped = Arrays.stream(child.blocks()).map(p -> transformation.apply(BlockPos.of(p)).asLong()).toArray();
            groups.add(new Group(child.id(), remapped));
        }
        groups.add(new Group(UUID.randomUUID(), mapped.stream().mapToLong(Long::longValue).distinct().toArray()));
        if (groups.size() <= MAX_GROUPS) write(destination, groups);
    }

    public static @Nullable Group select(ServerSubLevel level, BlockPos clicked) {
        List<Group> gs = read(level);
        // Most recent merge wins, allowing nested undo operations in reverse order.
        for (int i = gs.size() - 1; i >= 0; i--)
            if (gs.get(i).contains(clicked.asLong())) return gs.get(i);
        return null;
    }

    /** Move nested group metadata to the new plot; drop the group that has just been undone. */
    public static void afterSplit(ServerSubLevel parent, ServerSubLevel separated, Group extracted, BlockPos anchor) {
        List<Group> remaining = new ArrayList<>();
        List<Group> moved = new ArrayList<>();
        HashSet<Long> extractedBlocks = new HashSet<>();
        for (long l : extracted.blocks()) extractedBlocks.add(l);
        BlockPos plotAnchor = separated.getPlot().getCenterBlock();
        for (Group g : read(parent)) {
            if (g.id().equals(extracted.id())) continue;
            boolean any = false, all = true;
            for (long p : g.blocks()) {
                boolean belongs = extractedBlocks.contains(p);
                any |= belongs;
                all &= belongs;
            }
            if (all) {
                long[] remapped = Arrays.stream(g.blocks()).map(p -> BlockPos.of(p).subtract(anchor).offset(plotAnchor).asLong()).toArray();
                moved.add(new Group(g.id(), remapped));
            } else if (!any) {
                remaining.add(g);
            }
            // Partial intersections are discarded, rather than allowing a later unsafe split.
        }
        write(parent, remaining);
        write(separated, moved);
    }

    private static List<Group> read(ServerSubLevel level) {
        List<Group> groups = new ArrayList<>();
        CompoundTag data = level.getUserDataTag();
        if (data == null || !data.contains(ROOT, Tag.TAG_COMPOUND)) return groups;
        ListTag list = data.getCompound(ROOT).getList(GROUPS, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            try {
                long[] blocks = t.getLongArray("blocks");
                if (blocks.length != 0 && blocks.length <= MAX_BLOCKS)
                    groups.add(new Group(UUID.fromString(t.getString("id")), blocks));
            } catch (IllegalArgumentException ignored) { }
        }
        return groups;
    }

    private static void write(ServerSubLevel level, List<Group> groups) {
        CompoundTag data = level.getUserDataTag() == null ? new CompoundTag() : level.getUserDataTag().copy();
        CompoundTag ours = new CompoundTag();
        ListTag list = new ListTag();
        for (Group group : groups) {
            CompoundTag t = new CompoundTag();
            t.putString("id", group.id().toString());
            t.putLongArray("blocks", group.blocks());
            list.add(t);
        }
        ours.put(GROUPS, list);
        data.put(ROOT, ours);
        level.setUserDataTag(data);
    }
}
